<?php

return [
	'nome' => 'Prontuário',
    'paginacao' => '5',
    'hospital' => [
    	'nome' => 'São José',
    	'local' => 'Ituiutaba-MG'
    ],
    'config' => [
    	'cid' => '0'
    ]
];