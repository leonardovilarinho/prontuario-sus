

<?php $__env->startSection('titulo', 'Criar uma evolução'); ?>

<?php $__env->startSection('conteudo'); ?>

    <p>
       Aqui você pode cadastrar uma nova evolução para <span class="texto-verde"><?php echo e($paciente->nome); ?></span>, preencha os campos vermelhos.
    </p>
                    
    <?php echo Form::open(['url' => 'pacientes/'.$paciente->id.'/evolucoes/nova', 'method' => 'post']); ?>

    	<?php echo e(Form::hidden('paciente_id', $paciente->id)); ?>

    	<?php echo e(Form::hidden('autor_id', auth()->user()->id)); ?>

        <header>
            Por favor, preencha os campos:
        </header>

        <section>
  
            <div>
                <?php echo Form::label('evolucao', 'Evolução'); ?>

                <?php echo Form::textarea('evolucao', '', ['required' => '', 'placeholder' => 'Detalhes da evolução']  ); ?>

            </div>

            <div>
                <?php echo Form::label('cid', 'CID'); ?>

                <input type="text" id="cid" name="cid" placeholder="Código CID"
                    <?php echo e(config('prontuario.config.cid') ? 'required' : ''); ?>

                >
            </div>
        </section>

        <footer>
            <section>
                <input type="submit" value="Salvar essa evolução" class="btn verde">
            </section>

            <span class="texto-vermelho"><?php echo e($errors->first()); ?></span>
        </footer>
    <?php echo Form::close(); ?>


    <script>
        CKEDITOR.config.width = '100%';
        CKEDITOR.replace( 'evolucao' );
        CKEDITOR.replace( 'diagnostico' );
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>