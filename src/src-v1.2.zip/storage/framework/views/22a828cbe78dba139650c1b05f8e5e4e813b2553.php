

<?php $__env->startSection('titulo', ''); ?>

<?php $__env->startSection('lateral'); ?>
    
    <li><a href="#">Entrar</a></li>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
    <section class="container">
    	<?php echo Form::open(['url' => '/', 'method' => 'post', 'autocomplete' => 'off']); ?>

	        <header>
	            Entre no sistema
	        </header>

	        <section>
	            <div>
	                <?php echo Form::label('email', 'Email'); ?>

	                <?php echo Form::email('email', '', ['required' => '', 'minlength' => 3, 'autocomplete' => 'off']); ?>

	            </div>

	            <div>
	                <?php echo Form::label('senha', 'Senha'); ?>

	                <?php echo Form::password('senha', ['required' => '', 'minlength' => 6, 'autocomplete' => 'off']); ?>

	            </div>
	        </section>

	        <footer>
	            <span class="texto-vermelho"><?php echo e($errors->first()); ?></span>

	            <?php if(session('erro')): ?>
	            	<span class="texto-vermelho"><?php echo session('erro'); ?></span>
	            <?php endif; ?>

	            <?php if(session('msg')): ?>
	            	<span class="texto-verde"><?php echo session('msg'); ?></span>
	            <?php endif; ?>

	            <section>
	                <input type="submit" value="Entrar" class="btn verde">
	            </section>
	        </footer>
	    <?php echo Form::close(); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>