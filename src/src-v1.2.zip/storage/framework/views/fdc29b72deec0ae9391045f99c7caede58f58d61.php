

<?php $__env->startSection('titulo', 'Painel gerencial'); ?>

<?php $__env->startSection('lateral'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>


    <p>
        Olá <span class="texto-verde"><?php echo e(auth()->user()->nome); ?></span>, a seguir disponibilizamos algumas contas sobre a quantidade de dados que temos no sistema, veja:
    </p>
    <br>

	<h2>Pessoas</h2>
    <article style="display: flex; flex-direction: row; justify-content: center; flex-wrap: wrap">
    	<section class="cartao">
	        <header>
	            Administradores
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($administradores); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	            -----Médicos-----
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($medicos); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	           --Não médicos--
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($nao_medicos); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	            ---Secretários---
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($secretarios); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	            ---Pacientes---
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($pacientes); ?></h4>
	        </article>
	    </section>
    </article>

    <h2>Papeladas</h2>
    <article style="display: flex; flex-direction: row; justify-content: center; flex-wrap: wrap">
    	<section class="cartao">
	        <header>
	           -Evoluções-
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($evolucoes); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	            Prescrições
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($prescricoes); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	           Receituários
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($receituarios); ?></h4>
	        </article>
	    </section>
    </article>

    <h2>Hospital</h2>
    <article style="display: flex; flex-direction: row; justify-content: center; flex-wrap: wrap">
    	<section class="cartao">
	        <header>
	           Equipamentos
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($equipamentos); ?></h4>
	        </article>
	    </section>

	    <section class="cartao">
	        <header>
	            Medicamentos
	        </header>
	        <article style="text-align: center; padding: 0px; margin: 0px">
	            <h4 style="font-size: 25pt; "><?php echo e($medicamentos); ?></h4>
	        </article>
	    </section>

    </article>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>