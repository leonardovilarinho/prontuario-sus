

<?php $__env->startSection('titulo', 'Gerenciar paciente'); ?>

<?php $__env->startSection('lateral'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

	<a href="<?php echo e(url('pacientes')); ?>" class="btn secundaria">Voltar</a>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>

    <section class="cartao" id="imprimir">
        <header>
            <?php echo e($paciente->nome); ?>

        </header>
        <article>
        	<figure style="float: right; border: 1px solid #eee">
                <img src="<?php echo e(Storage::url('pacientes/'.$paciente->id.'.jpg')); ?>" width="150" alt="Foto de <?php echo e($paciente->nome); ?>">
                <br>
                <small><a href="<?php echo e(url('pacientes/apagarfoto/'.$paciente->id)); ?>">Apagar imagem</a></small>
            </figure>

			<p>
            	<strong>Prontuário: </strong>
            	<?php echo e($paciente->prontuario); ?>

            </p>

            <p>
            	<strong>Leito: </strong>
            	<?php echo e($paciente->leito); ?>

            </p>

            <p>
            	<strong>Nascimento: </strong>
            	<?php echo e(date('d/m/Y', strtotime($paciente->nascimento))); ?>

            </p>

            <p>
            	<strong>Sexo: </strong>
            	<?php echo e($paciente->sexo); ?>

            </p>

            <p>
            	<strong>E. Civil: </strong>
            	<?php echo e($paciente->civil); ?>

            </p>

            <p>
            	<strong>Cor: </strong>
            	<?php echo e($paciente->cor); ?>

            </p>

            <p>
            	<strong>CPF: </strong>
            	<?php echo e($paciente->cpf); ?>

            </p>

            <p>
            	<strong>Convênio: </strong>
            	<?php echo e($paciente->convenio); ?>

            </p>

            <p>
            	<strong>N. Convênio: </strong>
            	<?php echo e($paciente->num_convenio); ?>

            </p>

            <p>
            	<strong>Nível de instrução: </strong>
            	<?php echo e($paciente->grau); ?>

            </p>

            <p>
            	<strong>Naturalidade: </strong>
            	<?php echo e($paciente->naturalidade); ?>

            </p>

			<p>
            	<strong>Profissão: </strong>
            	<?php echo e($paciente->profissao); ?>

            </p>

            <hr>

            <p>
            	<strong>Telefone: </strong>
            	<?php echo e($paciente->telefone); ?>

            </p>

            <p>
            	<strong>Email: </strong>
            	<?php echo e($paciente->email); ?>

            </p>

            <p>
            	<strong>CEP: </strong>
            	<?php echo e($paciente->cep); ?>

            </p>

            <p>
            	<strong>Endereço: </strong>
            	<?php echo e($paciente->endereco); ?>

            </p>

            <p>
            	<strong>Bairro: </strong>
            	<?php echo e($paciente->bairro); ?>

            </p>

            <p>
            	<strong>Cidade: </strong>
            	<?php echo e($paciente->cidade); ?> - <?php echo e($paciente->uf); ?>

            </p>
            
            <hr>

            <p>
            	<strong>Observação: </strong>
            	<?php echo $paciente->obs; ?>

            </p>

            <hr>

            <p style="text-align: right;">
            	<small>
            		<strong>Criado em: </strong>
	            	<?php echo e(date('d/m/Y á\s H:i', strtotime($paciente->created_at))); ?>

					|
	            	<strong>Última edição: </strong>
	            	<?php echo e(date('d/m/Y á\s H:i', strtotime($paciente->updated_at))); ?>

            	</small>
            </p>

        </article>
        <footer style="text-align: right">

        	<?php if(auth()->user()->secretario): ?>
                <a href="<?php echo e(url('pacientes/apagar/' . $paciente->id)); ?>" onclick="return confirm('Deseja apagar?')" class="btn vermelho">Apagar</a>
                <a href="<?php echo e(url('pacientes/editar/' . $paciente->id)); ?>" class="btn amarelo">Editar</a>

                <a href="<?php echo e(url('pacientes/' . $paciente->id .'/consultas')); ?>" class="btn verde">Consultas</a>
            <?php else: ?>
                <a href="<?php echo e(url('pacientes/' . $paciente->id .'/evolucoes')); ?>" class="btn amarelo">Evoluções</a>

                <a href="<?php echo e(url('pacientes/' . $paciente->id .'/receituarios')); ?>" class="btn azul">Receituários</a>

                <a href="<?php echo e(url('pacientes/' . $paciente->id .'/prescricoes')); ?>" class="btn verde">Prescrição</a>
            <?php endif; ?>
            <button onclick="printDiv('imprimir')" class="btn verde oculta-tel">Imprimir</button>
        </footer>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>