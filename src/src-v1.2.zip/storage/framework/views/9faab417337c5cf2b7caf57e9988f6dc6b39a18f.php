

<?php $__env->startSection('titulo', 'Criar um receituário'); ?>

<?php $__env->startSection('conteudo'); ?>

    <p>
       Aqui você pode cadastrar um novo receituário para <span class="texto-verde"><?php echo e($paciente->nome); ?></span>, preencha os campos vermelhos.
    </p>

    <?php echo Form::open(['url' => 'pacientes/'.$paciente->id.'/receituarios/novo', 'method' => 'post']); ?>

    	<?php echo e(Form::hidden('paciente_id', $paciente->id)); ?>

    	<?php echo e(Form::hidden('autor_id', auth()->user()->id)); ?>

        <header>
            Por favor, preencha os campos:
        </header>

        <section>
            <div>
                <?php echo Form::label('conteudo', 'Conteúdo'); ?>

                <?php echo Form::textarea('conteudo', '', ['required' => '', 'placeholder' => 'Conteúdo do receituário']); ?>

            </div>
        </section>

        <footer>
            <section>
                <input type="submit" value="Salvar essa receituário" class="btn verde">
            </section>

            <span class="texto-vermelho"><?php echo e($errors->first()); ?></span>
        </footer>
    <?php echo Form::close(); ?>



     <script>
        CKEDITOR.config.width = '100%';
        CKEDITOR.replace( 'conteudo' );
    </script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>