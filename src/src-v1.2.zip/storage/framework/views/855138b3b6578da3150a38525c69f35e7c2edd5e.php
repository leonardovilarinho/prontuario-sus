

<?php $__env->startSection('titulo', 'Gerenciamento de pacientes'); ?>

<?php $__env->startSection('lateral'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>

    <?php echo e(Form::open(['url' => 'pacientes', 'method' => 'get'])); ?>

        <section>
            <div>
                <?php echo e(Form::search('q', '',['placeholder' => 'Buscar por nome, email, CPF, prontuario ou nascimento'])); ?>

                <?php echo e(Form::submit('Buscar', ['class' => 'btn verde', 'style' => 'flex-grow: 1; margin-left: 3px'])); ?>

            </div>
        </section>
    <?php echo e(Form::close()); ?>


    <p>
        Aqui você pode gerenciar qualquer paciente registrado no sistema, veja a seguir alguns dos quais estão na sua base de dados:
    </p>
    <br>

    <?php if(auth()->user()->secretario): ?>
        <a class="btn verde" href="<?php echo e(url('pacientes/novo')); ?>">Cadastrar novo paciente</a>
    <?php endif; ?>

    <table>
        <tr>
            <td>Ações</td>
            <td>Nome</td>
            <td>Prontuário</td>
            <td>Sexo</td>
            <td>Idade</td>
            <td>Leito</td>
            <td>Convênio</td>
            <td>Nascimento</td>
        </tr>

        <?php $__currentLoopData = $pacientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $paciente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a href="<?php echo e(url('pacientes/gerenciar/' . $paciente->id)); ?>" class="btn azul">Gerenciar</a>
                </td>
                <td><?php echo e($paciente->nome); ?></td>
                <td><?php echo e($paciente->prontuario); ?></td>
                <td><?php echo e($paciente->sexo); ?></td>
                <td><?php echo e(Saudacoes::idade($paciente->nascimento)); ?> ano(s)</td>
                <td><?php echo e($paciente->leito != null ? $paciente->leito : 'n/d'); ?></td>
                <td><?php echo e($paciente->convenio); ?></td>
                <td><?php echo e(date('d/m/Y', strtotime($paciente->nascimento))); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <section style="text-align:center">
        <?php echo e($pacientes->links()); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>