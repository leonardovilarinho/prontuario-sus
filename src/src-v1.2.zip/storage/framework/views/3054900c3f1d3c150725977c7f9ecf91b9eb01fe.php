<!DOCTYPE html>
<html lang="<?php echo e(app()->getLocale()); ?>">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width">

        <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
        <title><?php echo $__env->yieldContent('titulo'); ?> - <?php echo e(config('prontuario.nome')); ?></title>
        <link href="<?php echo e(asset('css/app.css')); ?>" rel="stylesheet">
        <link href="<?php echo e(asset('css/app.mob.css')); ?>" rel="stylesheet" media="(max-width: 992px)">
        <script src="<?php echo e(asset('ckeditor/ckeditor.js')); ?>"></script>
    </head>

    <body class="pagina">

        <header class="superior">
            <section class="logo">
                <span>
                    <?php echo e(config('prontuario.nome')); ?>

                </span>
            </section>

            <nav class="links">
                <?php if(!Auth::guest()): ?>
                    <ul>
                        <li><a href="<?php echo e(url('perfil')); ?>">Perfil</a></li>
                        <li><a href="<?php echo e(url('sair')); ?>">Sair</a></li>
                    </ul>
                <?php endif; ?>
            </nav>
        </header>

        <main>
            <div id="topo"></div>

            <aside class="lateral">
                <section class="titulo">
                    <?php if(Auth::guest()): ?>
                        <p><?php echo Saudacoes::gerar(); ?></p>
                    <?php else: ?>
                        <p>Olá, <?php echo e(explode(' ', auth()->user()->nome)[0]); ?></p>
                        <small><?php echo e(date('d/m/Y H:i')); ?></small>
                        <small><?php echo e(auth()->user()->tipo()); ?></small>
                    <?php endif; ?>
                </section>

                <nav class="menu">
                    <ul>
                        <li class="fixo"><span>Ações a fazer:</span></li>
                        <?php if(!auth()->guest()): ?>
                            <li><a href="<?php echo e(url('painel')); ?>">Inicial</a></li>
                            <?php if(auth()->user()->administrador): ?>
                                <li><a href="<?php echo e(url('postos')); ?>">Postos</a></li>
                                <li><a href="<?php echo e(url('administradores')); ?>">Administradores</a></li>
                                <li><a href="<?php echo e(url('medicos')); ?>">Médicos</a></li>
                                <li><a href="<?php echo e(url('nao-medicos')); ?>">Profissionais</a></li>
                                <li><a href="<?php echo e(url('secretarios')); ?>">Secretários</a></li>
                                <li><a href="<?php echo e(url('pacientes')); ?>">Pacientes</a></li>
                                <li><a href="<?php echo e(url('hospital/medicamentos')); ?>">Medicamentos</a></li>
                                <li><a href="<?php echo e(url('hospital/equipamentos')); ?>">Equipamentos</a></li>
                                <li><a href="<?php echo e(url('hospital/config')); ?>">Configurações</a></li>

                            <?php elseif(auth()->user()->medico): ?>
                                <li><a href="<?php echo e(url('pacientes')); ?>">Pacientes</a></li>
                                <li><a href="<?php echo e(url('medicos/financas')); ?>">Finanças</a></li>
                                <li><a href="<?php echo e(url('medicos/config')); ?>">Configurações</a></li>

                            <?php elseif(auth()->user()->secretario): ?>
                                <li><a href="<?php echo e(url('pacientes')); ?>">Pacientes</a></li>
                                <li><a href="<?php echo e(url('medicos')); ?>">Médicos</a></li>
                                <li><a href="<?php echo e(url('secretarios')); ?>">Secretários</a></li>

                            <?php elseif(auth()->user()->nao_medico): ?>
                                <li><a href="<?php echo e(url('pacientes')); ?>">Pacientes</a></li>
                            <?php endif; ?>
                        <?php endif; ?>
                        <li><a href="<?php echo e(url('sobre')); ?>">Sobre</a></li>
                        <?php $__env->startSection('lateral'); ?>
                        <?php echo $__env->yieldSection(); ?>
                    </ul>
                </nav>
            </aside>

            <article class="conteudo">
                <span class="caminho">
                    <?php if(count(Request::segments()) > 0): ?>
                        <?php for($i = 0; $i <= count(Request::segments()); $i++): ?>
                            <?php if(Request::segment($i) != ''): ?>
                                <a href="#"><?php echo e(Request::segment($i)); ?></a>
                            <?php endif; ?>
                        <?php endfor; ?>
                    <?php else: ?>
                        <a href="<?php echo e(url('/')); ?>">Login</a>
                    <?php endif; ?>

                </span>

                <h1><?php echo $__env->yieldContent('titulo'); ?></h1>

                <?php echo $__env->yieldContent('conteudo'); ?>
            </article>
        </main>

        <footer class="rodape">
            <span>&copy; Desenvolvido com licença GPL v3 - <?php echo e(date('Y')); ?></span>
            <a href="#topo">Topo</a>
        </footer>

        <script src="<?php echo e(asset('js/app.js')); ?>"></script>
        <script type="text/javascript">
            function printDiv(divName) {
                 var printContents = document.getElementById(divName).innerHTML;
                 var originalContents = document.body.innerHTML;

                 document.body.innerHTML = printContents;

                 window.print();

                 document.body.innerHTML = originalContents;
            }
        </script>
    </body>
</html>
