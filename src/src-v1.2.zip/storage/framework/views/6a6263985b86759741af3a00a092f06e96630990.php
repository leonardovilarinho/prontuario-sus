

<?php $__env->startSection('titulo', 'Evoluções de ' . $paciente->nome); ?>

<?php $__env->startSection('lateral'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>

    <a href="<?php echo e(url('pacientes/gerenciar/'.$paciente->id)); ?>" class="btn secundaria">Voltar</a>

    <?php echo e(Form::open(['url' => 'pacientes/'.$paciente->id.'/evolucoes', 'method' => 'get'])); ?>

        <section>
            <div>
                <?php echo e(Form::search('q', '',['placeholder' => 'Buscar por autor, horário, cid ou resumo'])); ?>

                <?php echo e(Form::submit('Buscar', ['class' => 'btn verde', 'style' => 'flex-grow: 1; margin-left: 3px'])); ?>

            </div>
        </section>
    <?php echo e(Form::close()); ?>


    <p>
        Aqui você pode gerenciar as evoluções do paciente <span class="texto-verde"><?php echo e($paciente->nome); ?></span>:
    </p>
    <br>
    
    <?php if(!auth()->user()->administrador): ?>
        <a class="btn verde" href="<?php echo e(url('pacientes/'.$paciente->id.'/evolucoes/nova')); ?>">
            Cadastrar nova evolução
        </a>
    <?php endif; ?>

    <table>
        <tr>
            <td>Ações</td>
            <td>Autor</td>
            <td>Horário</td>
            <td>CID</td>
            <td>Posto</td>
            
        </tr>

        <?php $__currentLoopData = $paciente->evolucoes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $evolucao): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <?php if(auth()->user()->administrador): ?>
                        <a href="<?php echo e(url('pacientes/evolucoes/' . $evolucao->id . '/apagar')); ?>" onclick="return confirm('Deseja apagar?')" class="btn vermelho">Apagar</a>
                    <?php endif; ?>
                    <a href="<?php echo e(url('pacientes/' . $paciente->id .'/evolucoes/'.$evolucao->id.'/detalhes')); ?>"
                    	class="btn verde"
                    >
                        Detalhes
                    </a>
                </td>
                <td><?php echo e($evolucao->autor->nome); ?></td>
                <td><?php echo e(date('d/m/Y H:i', strtotime($evolucao->created_at))); ?></td>
                <td><?php echo e(($evolucao->cid  != null) ? $evolucao->cid : 'n/d'); ?></td>
                <td><?php echo e($evolucao->cabecalho->nome . ' - ' . $evolucao->cabecalho->local); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <section style="text-align:center">
        <?php echo e($paciente->evolucoes->links()); ?>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>