

<?php $__env->startSection('titulo', 'Gerenciar secretário'); ?>

<?php $__env->startSection('lateral'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

	<a href="<?php echo e(url('secretarios')); ?>" class="btn secundaria">Voltar</a>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>

    <section class="cartao" id="imprimir">
        <header>
            <?php echo e($secretario->usuario->nome); ?>

        </header>
        <article>
            <p>
            	<strong>Email: </strong>
            	<?php echo e($secretario->usuario->email); ?>

            </p>

            <p>
            	<strong>CPF: </strong>
            	<?php echo e($secretario->usuario->cpf); ?>

            </p>

            <p>
            	<strong>Nascimento: </strong>
            	<?php echo e(date('d/m/Y', strtotime($secretario->usuario->nascimento))); ?>

            </p>

            <p>
            	<strong>Status: </strong>
            	<?php echo e(($secretario->usuario->valido) ? 'Ativo' : 'Inativo'); ?>

            </p>

            <p>
            	<strong>Cargo: </strong>
            	<?php echo e($secretario->cargo); ?>

            </p>

            <p>
            	<strong>Telefone: </strong>
            	<?php echo e($secretario->telefone); ?>

            </p>

            <hr>

            <p style="text-align: right;">
            	<small>
            		<strong>Criado em: </strong>
	            	<?php echo e(date('d/m/Y á\s H:i', strtotime($secretario->usuario->created_at))); ?>

					|
	            	<strong>Última edição: </strong>
	            	<?php echo e(date('d/m/Y á\s H:i', strtotime($secretario->usuario->updated_at))); ?>

            	</small>
            </p>

        </article>
        <footer style="text-align: right">

            <?php if(auth()->user()->administrador): ?>
                <a href="<?php echo e(url('usuarios/apagar/' . $secretario->usuario->id)); ?>" onclick="return confirm('Deseja apagar?')" class="btn vermelho">Apagar</a>

                <a href="<?php echo e(url('secretarios/editar/' . $secretario->id)); ?>" class="btn amarelo">Editar</a>

                <?php if($secretario->usuario->valido): ?>
                    <a href="<?php echo e(url('usuarios/bloquear/' . $secretario->usuario->id)); ?>" class="btn azul">Bloquear</a>
                <?php else: ?>
                    <a href="<?php echo e(url('usuarios/desbloquear/' . $secretario->usuario->id)); ?>" class="btn azul">Desbloquear</a>
                <?php endif; ?>

                <a href="<?php echo e(url('usuarios/redefinir/' . $secretario->usuario->id)); ?>" class="btn verde">Redefinir senha</a>
            <?php endif; ?>
        	 


            <button onclick="printDiv('imprimir')" class="btn verde oculta-tel">Imprimir</button>
        </footer>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>