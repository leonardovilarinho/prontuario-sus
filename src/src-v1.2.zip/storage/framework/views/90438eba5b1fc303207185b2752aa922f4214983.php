

<?php if($medico->usuario->nome == ''): ?>
    <?php $__env->startSection('titulo', 'Criar um novo médico'); ?>
<?php else: ?>
    <?php $__env->startSection('titulo', 'Editar esse médico'); ?>
<?php endif; ?>

<?php $__env->startSection('conteudo'); ?>
    <?php if($medico->usuario->nome == ''): ?>
        <p>
           Aqui você pode cadastrar um novo médico no sistema, os campos em vermelhos são obrigatórios, então devem ser preenchidos.
        </p>

        <p class="texto-vermelho" style="text-align: right">
            A senha padrão do usuário será o CPF do mesmo.
        </p>
    <?php else: ?>
        <p>
           Aqui você pode editar o registro de '<?php echo e($medico->usuario->nome); ?>', os campos em vermelhos são obrigatórios, então devem ser preenchidos.
        </p>
    <?php endif; ?>

    <?php if($medico->usuario->nome == ''): ?>
        <?php echo Form::open(['url' => 'medicos/novo', 'method' => 'post']); ?>

    <?php else: ?>
        <?php echo Form::open(['url' => 'medicos/editar/'.$medico->id, 'method' => 'post']); ?>

            <?php echo e(Form::hidden('_method', 'put')); ?>

    <?php endif; ?>
        <header>
            Por favor, preencha os campos:
        </header>

        <section>
            <div>
                <?php echo Form::label('nome', 'Nome'); ?>

                <?php echo Form::text('nome', $medico->usuario->nome, ['required' => '', 'placeholder' => 'Seu nome completo']); ?>

            </div>

             <div>
                <?php echo Form::label('email', 'Email'); ?>

                <?php echo Form::email('email', $medico->usuario->email, ['required' => '', 'placeholder' => 'Seu endereço de email']); ?>


                <?php echo Form::label('cpf', 'CPF'); ?>

                <?php echo Form::text('cpf', $medico->usuario->cpf, ['required' => '', 'placeholder' => 'Seu número de CPF', 'maxlength' => 11]); ?>

            </div>

            <div>
                <?php echo Form::label('nascimento', 'Data de nascimento'); ?>

                <?php echo Form::date('nascimento', $medico->usuario->nascimento, ['required' => '']); ?>


                <?php echo Form::label('cargo', 'Cargo'); ?>

                <?php echo Form::text('cargo', $medico->cargo); ?>


                <?php echo Form::label('especialidade', 'Especialidade'); ?>

                <?php echo Form::text('especialidade', $medico->especialidade); ?>

            </div>

            <div>
                <?php echo Form::label('conselho', 'Conselho regional'); ?>

                <?php echo Form::text('conselho', $medico->conselho); ?>


                <?php echo Form::label('telefone', 'Telefone'); ?>

                <?php echo Form::text('telefone', $medico->telefone); ?>

            </div>
        </section>

        <footer>
            <section>
                <input type="submit" value="Salvar esse médico" class="btn verde">
            </section>

            <span class="texto-vermelho"><?php echo e($errors->first()); ?></span>
        </footer>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>