

<?php $__env->startSection('titulo', 'Suas finanças'); ?>

<?php $__env->startSection('lateral'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>
	<script type="text/javascript">
		function alterarValor(preco, id) {
			var el = document.getElementById('valor');
			el.value = preco.replace(',', '.');

			el = document.getElementById('id');
			console.log(el);
			el.value = id;

			var oculto = document.getElementById('formval');
			oculto.style.display = '';
		}
	</script>
    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>

    <?php echo e(Form::open(['url' => 'medicos/financas', 'method' => 'get'])); ?>

		<section>
			<div>
				<?php echo e(Form::label('data', 'Data')); ?>

				<?php echo e(Form::date('data',  date('Y-m-d', strtotime($_GET['data'])), ['required' => ''])); ?>


				<?php echo e(Form::submit('Buscar', ['class' => 'btn verde', 'style' => 'flex-grow: 1; margin-left: 3px'])); ?>

			</div>
		</section>
    <?php echo e(Form::close()); ?>

    <section id="imprimir">
	    <br>

		<?php if(count($n_atendidas) > 0): ?>
			<ul class="lista-vermelha">
		        <?php $__currentLoopData = $n_atendidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        	<li>
		        		<span>
		        			<?php echo e(date('d/m/Y á\s H:i', strtotime($consulta->horario))); ?> -
		        			<?php echo e($consulta->paciente->nome); ?> |
		        			<?php echo e(Saudacoes::idade($consulta->paciente->nascimento)); ?> ano(s)|
		        			R$ <?php echo e(number_format($consulta->valor, 2, ',', '.')); ?>

		        		</span>

		        		<div class="direita">
			                <a href="<?php echo e(url('pacientes/gerenciar/'.$consulta->paciente->id)); ?>" class="btn azul">Paciente</a>
			                <a onclick="alterarValor('<?php echo e($consulta->valor); ?>', <?php echo e($consulta->id); ?>)" class="btn amarelo">Trocar valor</a>
			            </div>
		        	</li>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </ul>
		<?php endif; ?>

		<?php if(count($atendidas) > 0): ?>
			<ul class="lista-verde">
		        <?php $__currentLoopData = $atendidas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		        	<li>
		        		<span>
		        			<?php echo e(date('d/m/Y á\s H:i', strtotime($consulta->horario))); ?> -
		        			<?php echo e($consulta->paciente->nome); ?> |
		        			<?php echo e(Saudacoes::idade($consulta->paciente->nascimento)); ?> ano(s) |
		        			R$ <?php echo e(number_format($consulta->valor, 2, ',', '.')); ?>

		        		</span>

		        		<div class="direita">
			                <a href="<?php echo e(url('pacientes/gerenciar/'.$consulta->paciente->id)); ?>" class="btn azul">Paciente</a>
			                <a onclick="alterarValor('<?php echo e($consulta->valor); ?>', <?php echo e($consulta->id); ?>)" class="btn amarelo">Trocar valor</a>
			            </div>
		        	</li>
		        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
		    </ul>
		<?php endif; ?>
	</section>

	<?php echo e(Form::open(['url' => 'medicos/financas', 'method' => 'get', 'id' => 'formval'])); ?>

		<section>
			<div>
				<?php echo e(Form::label('valor', 'Novo valor da consulta')); ?>

				<?php echo e(Form::number('valor', null,['required' => '', 'step' => 0.1])); ?>

				<?php echo e(Form::hidden('id', null, ['required' => '', 'id' => 'id'])); ?>

				<?php echo e(Form::hidden('data', date('Y-m-d', strtotime($_GET['data'])), ['required' => ''])); ?>


				<?php echo e(Form::submit('Alterar o valor', ['class' => 'btn verde', 'style' => 'flex-grow: 1; margin-left: 3px'])); ?>

			</div>
		</section>
    <?php echo e(Form::close()); ?>

    <br>


	<button onclick="printDiv('imprimir')" class="btn verde oculta-tel">Imprimir</button>

	<script>
		var oculto = document.getElementById('formval');
		oculto.style.display = 'none';
	</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>