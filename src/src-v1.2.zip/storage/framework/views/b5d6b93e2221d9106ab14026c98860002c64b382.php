

<?php if($posto->nome == ''): ?>
    <?php $__env->startSection('titulo', 'Criar um novo posto'); ?>
<?php else: ?>
    <?php $__env->startSection('titulo', 'Editar esse posto'); ?>
<?php endif; ?>

<?php $__env->startSection('conteudo'); ?>
    <?php if($posto->nome == ''): ?>
        <p>
           Aqui você pode cadastrar um novo posto no sistema, os campos em vermelhos são obrigatórios, então devem ser preenchidos.
        </p>
    <?php else: ?>
        <p>
           Aqui você pode editar o registro de '<?php echo e($posto->nome); ?>', os campos em vermelhos são obrigatórios, então devem ser preenchidos.
        </p>
    <?php endif; ?>

    <?php if($posto->nome == ''): ?>
        <?php echo Form::open(['url' => 'postos/novo', 'method' => 'post', 'files' => true]); ?>

    <?php else: ?>
        <?php echo Form::open(['url' => 'postos/editar/'.$posto->id, 'method' => 'post', 'files' => true]); ?>

            <?php echo e(Form::hidden('_method', 'put')); ?>

    <?php endif; ?>
        <header>
            Por favor, preencha os campos:
        </header>

        <section>

            <?php if($posto->nome != ''): ?>
                <figure style="text-align:center">
                    <img src="<?php echo e(Storage::url('postos/'.$posto->id.'.jpg')); ?>" width="250" alt="Logo de <?php echo e($posto->local); ?>">
                </figure>
            <?php endif; ?>

            <div>
                <?php echo Form::label('nome', 'Nome'); ?>

                <?php echo Form::text('nome', $posto->nome, ['required' => '', 'placeholder' => 'Nome completo posto']); ?>

            </div>

            <div>
                <?php echo Form::label('local', 'Local'); ?>

                <?php echo Form::text('local', $posto->local, ['required' => '', 'placeholder' => 'Endereço completo do posto']); ?>

            </div>

            <div>   
                <?php echo Form::label('logo', 'Logomarca'); ?>

                <?php echo Form::file('logo', ['accept' => 'image/*']); ?>

            </div>

        </section>

        <footer>
            <section>
                <input type="submit" value="Salvar esse posto" class="btn verde">
            </section>

            <span class="texto-vermelho"><?php echo e($errors->first()); ?></span>
        </footer>
    <?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>