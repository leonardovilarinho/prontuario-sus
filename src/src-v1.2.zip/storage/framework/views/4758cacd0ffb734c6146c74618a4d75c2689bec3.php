

<?php $__env->startSection('titulo', 'Gerenciar posto'); ?>

<?php $__env->startSection('lateral'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

	<a href="<?php echo e(url('postos')); ?>" class="btn secundaria">Voltar</a>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>

    <section class="cartao" id="imprimir">
        <header>
            <?php echo e($posto->nome); ?>

        </header>
        <article>

            <figure style="text-align:center; height: 200px">
                <img src="<?php echo e(Storage::url('postos/'.$posto->id.'.jpg')); ?>" alt="Logo de <?php echo e($posto->local); ?>">
            </figure>

            <p>
            	<strong>Local: </strong>
            	<?php echo e($posto->local); ?>

            </p>

        </article>
        <footer style="text-align: right">

            <?php if(auth()->user()->administrador): ?>
                <?php if($posto->atendida): ?>
                    <a href="<?php echo e(url('postos/desativar/' . $posto->id)); ?>" onclick="return confirm('Deseja desativar?')" class="btn vermelho">Desativar</a>
                <?php else: ?>
                    <a href="<?php echo e(url('postos/ativar/' . $posto->id)); ?>" onclick="return confirm('Deseja ativar?')" class="btn vermelho">Ativar</a>
                <?php endif; ?>

                <a href="<?php echo e(url('postos/editar/' . $posto->id)); ?>" class="btn amarelo">Editar</a>
            <?php endif; ?>


            <button onclick="printDiv('imprimir')" class="btn verde oculta-tel">Imprimir</button>
        </footer>
    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>