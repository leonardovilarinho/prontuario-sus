

<?php $__env->startSection('titulo', 'Lista de consultas'); ?>

<?php $__env->startSection('lateral'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo'); ?>

    <p style="text-align:center">
        <?php if(session('msg')): ?>
            <span class="texto-verde">
                <?php echo e(session('msg')); ?>

            </span>
        <?php endif; ?>

         <?php if(session('erro')): ?>
            <span class="texto-vermelho">
                <?php echo e(session('erro')); ?>

            </span>
        <?php endif; ?>
    </p>


    <p>
        A seguir são exibidas as consultas marcadas para <span class="texto-verde"><?php echo e(($tipo == 'med') ? $medico->usuario->nome : $paciente->nome); ?></span>:
    </p>
    <br>




    <?php if($tipo == 'med'): ?>
        <?php echo e(Form::open(['url' => 'medicos/'.$medico->usuario_id.'/consultas', 'method' => 'get'])); ?>

            <section>
                <div>
                    <?php echo e(Form::search('q', '',['placeholder' => 'Buscar por data, hora, paciente (nome, email ou cpf) ou status'])); ?>

                    <?php echo e(Form::submit('Buscar', ['class' => 'btn verde', 'style' => 'flex-grow: 1; margin-left: 3px'])); ?>

                </div>
            </section>
        <?php echo e(Form::close()); ?>

    <?php else: ?>
        <?php echo e(Form::open(['url' => 'pacientes/'.$paciente->id.'/consultas', 'method' => 'get'])); ?>

            <section>
                <div>
                    <?php echo e(Form::search('q', '',['placeholder' => 'Buscar por data, hora, paciente (nome, email ou cpf) ou status'])); ?>

                    <?php echo e(Form::submit('Buscar', ['class' => 'btn verde', 'style' => 'flex-grow: 1; margin-left: 3px'])); ?>

                </div>
            </section>
        <?php echo e(Form::close()); ?>

    <?php endif; ?>

    <?php if($tipo == 'med'): ?>
        <a class="btn verde" href="<?php echo e(url('medicos/'.$medico->usuario_id.'/consulta/data')); ?>">
            Cadastrar nova consulta
        </a>
    <?php endif; ?>

	<table>
        <tr>
            <td>Ações</td>
            <?php if($tipo == 'med'): ?>
                <td>Tempo</td>
            <?php endif; ?>
            <td>Horário</td>
            <?php if($tipo == 'med'): ?>
                <td>Paciente</td>
            <?php else: ?>
                <td>Médico</td>
            <?php endif; ?>
            <td>Estado</td>
            <td>Preço</td>
            <td>Observação</td>
        </tr>

        <?php $__currentLoopData = $consultas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $consulta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td>
                    <a onclick="return confirm('Deseja cancelar essa consulta?')"
                    href="<?php echo e(url('medicos/'.$consulta->medico_id.'/consulta/'.$consulta->id.'/cancelar')); ?>"
                    class="btn vermelho">
                        Cancelar
                    </a>
                </td>

                <?php if($tipo == 'med'): ?>
                    <td>

                        <?php if($consulta->atendida): ?>
                            <a href="#" class="btn verde">Concluída</a>
                        <?php else: ?>
                            <a href="#" class="btn vermelho">Pendente</a>
                        <?php endif; ?>
                    </td>
                <?php endif; ?>

                <td><?php echo e(date('d/m/Y á\s H:i', strtotime($consulta->horario))); ?></td>
                <?php if($tipo == 'med'): ?>
                    <td><?php echo e($consulta->paciente->nome); ?></td>
                <?php else: ?>
                    <td><?php echo e($consulta->medico->nome); ?></td>
                <?php endif; ?>
                <td><?php echo e($consulta->status); ?></td>
                <td>R$ <?php echo e(number_format($consulta->valor, 2, ',', '.')); ?></td>
                <td><?php echo e($consulta->obs); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>

    <section style="text-align:center">
        <?php echo e($consultas->links()); ?>

    </section>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>